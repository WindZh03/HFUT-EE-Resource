
#ifndef  DS18B20_H
#define  DS18B20_H

short read_temp();
#endif




