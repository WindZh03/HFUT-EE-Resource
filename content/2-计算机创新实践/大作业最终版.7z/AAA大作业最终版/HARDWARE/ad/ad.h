

#ifndef  AD_H
#define  AD_H
#include "sys.h"

u16 GetADCResult(u8 ch);  //��ȡP1.0��ADֵ


#endif





