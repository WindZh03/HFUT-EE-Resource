

#ifndef PCA_H
#define PCA_H


void pca(void);
#endif




