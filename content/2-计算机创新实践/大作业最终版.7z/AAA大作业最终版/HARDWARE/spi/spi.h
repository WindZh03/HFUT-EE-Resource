
#ifndef  SPI_H
#define  SPI_H

#include "sys.h"


void Init_SPI();		             //SPI��ʼ��
u8 SPI_SendByte(u8 SPI_SendData);	 //SPIΪȫ˫��ͨѶ
void SPI_Speed(u8 speed);			 //SPI�ٶȵ���
#endif




















