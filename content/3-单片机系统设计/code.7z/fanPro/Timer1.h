#ifndef __TIMER1_H__
#define __TIMER1_H__

void Timer1_Init(void);

#endif
